# =====================================================
# Streamlit Hotel FAQ Chatbot
# =====================================================

import streamlit as st
import spacy
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from collections import defaultdict
import joblib
import time
import numpy as np
import scipy.special

# -----------------------------
# 1️ Load models & spaCy
# -----------------------------
nlp = spacy.load("en_core_web_sm")
clf = joblib.load("svm_faq_model.joblib")
vectorizer = joblib.load("tfidf_vectorizer.joblib")

# -----------------------------
# 2️ Responses dictionary (fixed answers)
# -----------------------------
responses = {
    "greeting":                     "Welcome to Astra Imperium Hotel. I'm your virtual assistant. How may I assist you today?",
    "check_functions":              "I can help with room reservations, hotel information, facilities, services, and general inquiries.",

    "invoices":                     "To request an invoice, please visit the Front Desk or email us at billing@astraimperium.com. Provide your booking reference number for quicker processing.",
    "cancellation_fees":            "Cancellations are free up to 24 hours before your check-in date. Cancellations within 24 hours, or no-shows, will incur a charge equivalent to the first night's stay.",
    "check_in":                     "Check-in begins at 3:00 PM. Early check-in is subject to room availability. Luggage may be stored at the concierge at no additional cost. A refundable security deposit is required during check-in.",
    "check_out":                    "Check-out time is 12:00 PM. Late check-out until 2:00 PM is available for RM50, depending on availability. Please return your key card to the Front Desk upon departure.",
    "customer_service":             "For urgent assistance, please call the Front Desk at +60-3-5555-0199. For feedback and general inquiries, email us at support@astragroup.com.",
    "human_agent":                  "To speak with a hotel representative, please contact the Front Desk at +60-3-5555-0199 or request a callback by leaving your name and phone number.",
    "host_event":                   "To host an event, meeting, or private function at Astra Imperium, please email our Events Team at events@astragroup.com or call +60-3-5555-0200. Our coordinators will assist with venue selection, setup, and catering.",
    "file_complaint":               "To file a complaint, please speak to the Duty Manager at the Front Desk or email quality@astragroup.com. We will respond within 24 hours.",
    "leave_review":                 "You may leave a review on Google Maps, TripAdvisor, or our official website under the 'Guest Reviews' section. We appreciate your feedback.",
    "book_hotel":                   "To make a reservation, visit www.astraimperium.com, call our Reservations Department at +60-3-5555-0199, or book in person at the Front Desk. A valid ID is required for all bookings.",
    "cancel_hotel_reservation":     "To cancel your reservation, please contact our Reservations Team at +60-3-5555-0199 or email bookings@astragroup.com with your booking reference number.",
    "change_hotel_reservation":     "To modify your reservation dates, room type, or guest details, please contact our Reservations Team at +60-3-5555-0199 or email bookings@astragroup.com.",
    "check_hotel_facilities":       "Our facilities include an infinity pool, rooftop lounge, fitness centre, spa, business centre, event halls, all-day dining restaurant, and 24-hour concierge service.",
    "check_hotel_offers":           "Current promotions and packages are listed on our website under the 'Offers' section. You may also call our Reservations Team for exclusive in-house deals.",
    "check_hotel_prices":           "Room rates vary by date, room type, and availability. For the most accurate pricing, please check our website at www.astraimperium.com or call our Reservations Team.",
    "check_hotel_reservation":      "To check your reservation status, please provide your booking reference number to the Front Desk or email bookings@astragroup.com.",
    "search_hotel":                 "Astra Imperium Hotel is located at 18 Jalan Alor, Kuala Lumpur City Centre—just a 5-minute walk from LRT KLCC Station.",
    "store_luggage":                "Complimentary luggage storage is available 24/7. You may store your bags before check-in or after check-out while exploring the city.",
    "check_menu":                   "Our restaurant menu is available at the SkyDine Restaurant (Level 8). You may also view the digital menu through the QR code provided in your room or request a copy from the concierge.",
    "add_night":                    "To extend your stay or add additional guests, please contact the Front Desk or call +60-3-5555-0199. Extensions are subject to room availability and rate adjustments.",
    "book_parking_space":           "Parking can be reserved during booking or upon arrival, subject to availability. The rate is RM20 per day for in-house guests.",
    "bring_pets":                   "Astra Imperium is pet-friendly. Dogs and cats under 10kg are allowed with a RM50 per-stay cleaning fee. Service animals are welcome at no charge. Pets are not permitted in dining or pool areas.",
    "redeem_points":                "If you are an Astra Rewards member, you may redeem points for discounts or complimentary nights. Log in to your member account on our website or visit the Front Desk for assistance.",
    "get_refund":                   "Refunds are processed within 7-14 business days, depending on your payment method. Please contact billing@astragroup.com with your booking reference number.",
    "shuttle_service":              "We provide private airport transfers: RM80 for a sedan and RM120 for a van. Book at least 24 hours in advance via the Front Desk. E-hailing options are also easily available, averaging RM60-70 to KLIA.",

    "check_room_type":              "Our room categories include Superior, Deluxe, Premier, Executive Suite, and the Astra Imperial Suite. Each offers different views and amenities to suit your stay.",
    "check_room_availability":      "To check room availability, please visit our website's booking page or contact the Reservations Team with your preferred dates.",
    "check_nearby_attractions":     "Nearby attractions include the Petronas Twin Towers (1 km), Pavilion Bukit Bintang, the National Museum, and Jalan Alor Street Food Market. Complimentary city maps are available at the concierge.",
    "check_child_policy":           "Children under 12 stay for free using existing bedding. Baby cots and high chairs are available on request at no additional charge. Babysitting services are currently not offered.",
    "check_smoking_policy":         "All guest rooms are non-smoking. A penalty of RM500 applies for violations. Smoking is permitted only in the designated outdoor area near the main lobby.",
    "check_payment_methods":        "We accept cash (MYR), Visa, Mastercard, American Express, and major e-wallets such as GrabPay and Touch 'n Go. A refundable RM100 security deposit is required during check-in.",
    "check_lost_item":              "For lost items, please report immediately to the Front Desk. Our Security Team will review the Lost & Found log and contact you once the item is located.",
    "goodbye":                      "Thank you for choosing Astra Imperium Hotel. We look forward to welcoming you again soon!",
    "unknown_intent":                "I'm sorry, I don't understand your question."
}

# -----------------------------
# 3️Preprocess text
# -----------------------------
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    return text

# -----------------------------
# 4️Extract entities using spaCy NER
# -----------------------------
def extract_entities(text):
    doc = nlp(text)
    entities = defaultdict(list)
    for ent in doc.ents:
        entities[ent.label_].append(ent.text)
    return entities

# -----------------------------
# 5️ Predict intent & confidence
# -----------------------------
  

def predict_intent(text):
    start_time = time.time()
    vec = vectorizer.transform([preprocess_text(text)])
    scores = clf.decision_function(vec)
    best_index = np.argmax(scores)
    intent = clf.classes_[best_index]

    # Sigmoid convert margin to percentage
    if len(scores[0]) > 1:
        sorted_scores = np.sort(scores[0])[::-1]
        margin = sorted_scores[0] - sorted_scores[1]
    else:
        margin = scores[0][0]

    confidence = scipy.special.expit(margin) * 100 
    confidence = round(confidence, 2)# 

    response = responses.get(intent, responses["unknown_intent"])
    elapsed_time = time.time() - start_time
    return intent, response, confidence, elapsed_time



# -----------------------------
# 6️⃣ Streamlit Chat UI
# -----------------------------
st.set_page_config(page_title="Hotel FAQ Chatbot", layout="centered")
st.title("Astra Imperium Hotel FAQ Chatbot")
st.caption("SVM + TF-IDF + spaCy NER ")

if "messages" not in st.session_state:
    st.session_state.messages = []

def main():
    user_input = st.chat_input("How can I help you?")
    
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})
        
        # Predict intent
        intent_name, response, confidence_display, response_time = predict_intent(user_input)
        
        # Append assistant response
        st.session_state.messages.append({
            "role": "assistant",
            "content": response,
            "intent": intent_name,
            "confidence": confidence_display,
            "time": f"{response_time:.3f}s"
        })
    
    # Display chat history
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            with st.chat_message("user"):
                st.markdown(msg["content"])
        else:
            with st.chat_message("assistant"):
                st.caption(f"Intent: **{msg['intent']}** | Confidence: **{msg['confidence']}** | Time: **{msg['time']}**")
                st.markdown(msg["content"])

if __name__ == "__main__":
    main()








